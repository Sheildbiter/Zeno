ZENO BRAIN v0.10 — STANDALONE iPAD INSTALL

INSTALL (four steps)
1. Go to https://netlify.com/drop and upload zeno-v10-site.zip.
2. Open the Netlify link in Safari on the iPad.
3. Tap Initialize Brain once while online and let the first model download finish.
4. In Safari, tap Share → Add to Home Screen.

WHAT IS INCLUDED
- Three on-device brains: Fast, Medium, and Slow, with automatic routing,
  /fast /medium /slow /auto overrides, streaming replies, and one hot model
  at a time. WebLLM remains pinned at 0.2.82.
- Voice conversation orb with ready/listening/thinking/speaking states,
  interruption, speech input, spoken replies, and iPad system audio routing
  for AirPods/Bluetooth.
- Keyless public-web research with visible source links and honest failures.
- /imagine at 1024 × 1024 with local prompt art direction, optional reference
  image palette extraction, Save, Another version, Retry, and the written
  Fix-it loop. The reference photo itself is not uploaded to the free image
  generator; only its extracted palette is used.
- Versioned memory, notes, goals, reminders, voice settings, simulated mood,
  memory JSON export/import, and safe migration of older stored records.
- Service worker, manifest, and icons for an installable offline app shell.

STORAGE
On a standalone origin such as your Netlify site, Zeno uses this site's own
localStorage for small local records (memories and settings). Model files use
the browser cache managed by WebLLM. Closing and reopening the installed site
keeps those records. They are not uploaded to a Zeno server; the browser can
still remove website data if iPad storage is cleared, so keep an exported JSON
backup for anything important.

On the Muse-hosted artifact preview route only, Zeno automatically switches to
an in-memory session store. That keeps the hosted artifact compliant without
changing the standalone Netlify build.

FIRST-RUN NOTES
- Use Wi-Fi for the first brain download. Each brain downloads only the first
  time it is selected, then remains cached when iPadOS retains site data.
- Voice input uses Safari speech recognition and may require the Safari tab,
  internet access, and Siri enabled. Audio output follows the iPad's selected
  route, including connected AirPods.
- Web research and image generation use public third-party services. Do not
  include private information in web-research queries.
